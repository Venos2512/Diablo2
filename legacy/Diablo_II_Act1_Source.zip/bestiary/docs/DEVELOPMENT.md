# Mở rộng dự án

## Thêm hồ sơ

1. Thêm một dòng vào `src/data/catalog.js`: name, group, role, description, art, special motions, location, base reference.
2. Thêm ảnh vào `assets/references/` và entry trong `src/data/images.json` gồm src (data URI), file, url, source.
3. Ghi nguồn trong `assets/SOURCES.json`.
4. Cập nhật tổng cố định trong giao diện và kiểm tra (hiện tại dự án khóa ở 34 hồ sơ theo yêu cầu).
5. Chạy build và check. Xem cả desktop và màn hình nhỏ.

Tên tạo id ổn định dùng cho ghi chú. Khi đổi tên/id, cần chuyển dữ liệu ghi chú cũ nếu muốn giữ liên kết.

## Thay ảnh

Giữ name/id hồ sơ, thay `image.src` bằng data URI mới, cập nhật file/url/source. Không chỉ thay file trong assets: bundle đọc images.json. Script `fetch_assets.py` dành riêng cấu trúc HTML hiện tại của Blizzard; có kiểm tra khi không tìm được ảnh, cần rà lại nếu website thay đổi.

## Thay sân khấu bằng model thật

Module `viewer/stage.js` cung cấp giao diện select(monster), reset(), toggle(), dispose(). Có thể thêm GLTFLoader và trường model vào catalog; khi đổi quái phải hủy geometry/material/texture cũ, hủy tải quá hạn và tạo AnimationMixer nếu GLB có clip. Đặt tên từng clip thật và hiển thị danh sách; không gắn các tên checklist vào model khi chưa có animation tương ứng.

Hiện tại sân khấu dùng PlaneGeometry + CanvasTexture, giữ mặt ảnh hướng về camera. OrbitControls xoay camera quanh bệ, không cung cấp mặt sau của nhân vật. Sân khấu có fallback 2D khi WebGL khởi tạo thất bại.

## Giao diện

CSS dùng breakpoint 1650, 1150, 850 và 620px. Ở điện thoại hồ sơ nằm trước thư viện; chọn thẻ cuộn lên hồ sơ. Hộp thoại dùng dialog native, hỗ trợ Escape. Tab nội dung hỗ trợ phím mũi tên. Tìm kiếm chuẩn hóa dấu tiếng Việt.

## Dữ liệu ghi chú

Ghi chú dạng `{ [monsterId]: string }`, không gửi mạng. Xuất JSON gồm schemaVersion, exportedAt và notes. Text người dùng chỉ gán qua value/textContent, không render thành HTML. Chưa có nhập ghi chú; giữ file xuất làm bản sao.

## Kiểm thử

`npm run check`: đếm 34 id duy nhất; số lượng 8 nhóm; 21 thường, 12 đặc biệt và 1 boss; tồn tại 34 ảnh; logic lọc; tìm không dấu; bundle không còn placeholder và không tải script bên ngoài.

Kiểm tra trình duyệt: chọn quái mỗi nhóm, lọc không kết quả, nút xóa lọc, ghi chú theo từng hồ sơ, reload, xuất JSON, hộp ảnh, nguồn, WebGL, camera, desktop/mobile và file HTML trực tiếp khi offline.
