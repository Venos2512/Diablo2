# Kết quả kiểm tra

- Build HTML độc lập thành công, khoảng 1,38 MB.
- 34 id duy nhất, 8 nhóm với số lượng 5/6/7/2/3/5/3/3.
- 21 nhóm thường, 12 quái đặc biệt và 1 boss.
- Đủ 34 file hình và 34 ảnh data URI có nguồn.
- Kiểm tra tự động: tìm không dấu, lọc đặc biệt, tìm không kết quả, bundle không tải script bên ngoài.
- Trình duyệt localhost: trang trả HTTP 200, Three.js hiển thị sân khấu; không có console error/warning trong phiên kiểm tra.
- Đã kiểm tra tìm Pitspawn Fouldog, lọc Andariel, chuyển tab checklist, lưu ghi chú và giữ ghi chú sau reload, xóa bộ lọc, hộp tài liệu.
- Đã xem bố cục khung hẹp khoảng 480px và desktop 1440×1000. Ảnh desktop lưu tại preview.png.
- Trình duyệt kiểm thử không cho mở giao thức file://; chưa xác nhận bằng trình duyệt việc double-click HTML. Bundle dùng script inline và ảnh data URI, không có import/fetch runtime cho tài nguyên của ứng dụng.
- Chưa kiểm thử trực tiếp nút tải JSON trên mọi trình duyệt và chưa kiểm thử thiết bị không có WebGL. Fallback 2D đã được triển khai.

Bảng nhóm ở trao đổi trước thiếu Pitspawn Fouldog. Dự án đã bổ sung vào nhóm Quỷ thú & quái lớn; nhóm này có 5 mục, tổng đủ 34.
