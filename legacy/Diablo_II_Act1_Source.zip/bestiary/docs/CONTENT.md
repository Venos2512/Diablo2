# Phạm vi nội dung

## Danh mục

Giữ đúng 34 mục đã thống nhất trong cuộc trao đổi: 21 mục của Bestiary Act I và 13 mục đặc biệt của trang Super Unique Act I (bao gồm Andariel). Không thêm Act II–V, Cow Level, NPC, lính thuê hoặc triệu hồi.

Các con số là số mục tham khảo, không phải số model độc lập hay số loài theo dữ liệu engine. Danh mục chính thức có cách tổ chức riêng; không coi trang Act I là bằng chứng rằng mọi biến thể xuất hiện trong mọi khu Act I. Muốn chốt nội dung gameplay phải kiểm tra bảng spawn theo phiên bản và độ khó.

## Phân nhóm sản xuất

1. Quỷ nhỏ & pháp sư: 5 mục.
2. Rogue bị tha hóa: 6 mục.
3. Xác sống & bộ xương: 7 mục.
4. Linh thể & hắc ám: 2 mục.
5. Sinh vật hoang dã: 3 mục.
6. Quỷ thú & quái lớn: 5 mục, gồm Pitspawn Fouldog thuộc nhánh Tainted.
7. Kẻ thù đặc biệt: 3 mục.
8. Vật thể thù địch: 3 mục.

Đây là cách nhóm để tìm art dễ hơn, không phải phân loại Demon/Undead/Animal của engine. `base` chỉ là gợi ý đối chiếu hình nền, không xác nhận dùng chung rig, sprite hoặc clip.

## Nguồn hình

- Nhóm thường: ảnh minh họa trên từng trang bestiary (thường là GIF).
- Quái đặc biệt: ảnh chạm trán trong game trên trang Super Unique.
- Hình không được thay bằng minh họa AI hoặc model phỏng đoán.
- Ảnh có độ phân giải gốc thấp; phóng lớn dùng pixelated để giữ đặc trưng.

## Animation

`motions` là checklist đề xuất. Không có tổng số animation đã xác minh. Ảnh tham khảo không thể chứng minh mọi động tác tồn tại hoặc frame/direction chính xác. Cần dữ liệu MonStats/MonStats2, COF/DCC đúng bản game để kiểm kê. Phân biệt số clip, số hướng, số frame và thành phần hình.

## Nguồn chính

- https://classic.battle.net/diablo2exp/monsters/act1.shtml
- https://classic.battle.net/diablo2exp/monsters/act1-superuniques.shtml
- https://threejs.org/docs/

URL từng ảnh và trang cụ thể được ghi trong assets/SOURCES.json.
