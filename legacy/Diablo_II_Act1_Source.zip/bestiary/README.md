# Diablo II · Act I Bestiary

Thư viện tham khảo art bằng Three.js, gồm 34 hồ sơ trong 8 nhóm. Giao diện tiếng Việt, hình tham khảo chính thức, tìm kiếm không dấu, lọc nhóm/loại, sân khấu 3D, ảnh lớn và ghi chú cá nhân.

## Mở ngay

Mở `../Diablo_II_Act1_Bestiary.html` bằng Chrome hoặc Edge. Đây là file độc lập, đã nhúng toàn bộ ảnh và thư viện, dùng được offline. Hoặc mở `dist/index.html`.

Khung Three.js hiển thị ảnh 2D trên sân khấu 3D. Dự án chưa chứa model 3D của quái hoặc bộ animation trích xuất. Ảnh GIF tham khảo có thể có chuyển động nhưng không đại diện toàn bộ các động tác trong game. Khi WebGL không khả dụng, giao diện chuyển sang ảnh 2D.

## Chỉnh sửa và đóng gói

Yêu cầu Node.js 20+ và npm.

```sh
npm ci
npm run build
npm run check
npm start
```

Preview: http://127.0.0.1:4173. Build tạo `dist/index.html` và file HTML ở thư mục cha. Không cần server để mở bản HTML đã đóng gói. Các liên kết nguồn cần Internet.

## Cấu trúc

```text
src/
  data/catalog.js       8 nhóm, 34 hồ sơ, mô tả và checklist art
  data/images.json      Ảnh nhúng và nguồn từng ảnh
  lib/state.js          Tìm kiếm, lọc, lưu và xuất ghi chú
  viewer/stage.js       Scene/camera/ảnh tham khảo/OrbitControls Three.js
  main.js               Kết nối giao diện, lựa chọn và tương tác
  styles.css            Thiết kế và responsive
  template.html         Khung HTML, hộp hướng dẫn
assets/
  references/           34 file hình nguồn
  SOURCES.json          URL gốc và trang tham khảo
scripts/
  fetch_assets.py       Tải lại ảnh chính thức, có lưu provenance
  build.mjs             Bundle thành HTML độc lập
  serve.mjs             Server preview chỉ trên localhost
  check.mjs             Kiểm tra dữ liệu, lọc, ảnh và bundle
docs/
  CONTENT.md            Phạm vi và độ chính xác
  DEVELOPMENT.md        Hướng dẫn mở rộng module
```

## Ghi chú cá nhân

Ghi chú được lưu bằng localStorage với khóa `act1-bestiary-notes-v1`. Trình duyệt và đường dẫn khác có thể dùng kho lưu khác. Nút xuất JSON tạo bản sao toàn bộ ghi chú. Khi trình duyệt chặn lưu, trang thông báo để bạn xuất dữ liệu. Không có dữ liệu gửi lên server.

## Nguồn và quyền sử dụng

Hình Diablo II thuộc Blizzard Entertainment, lấy từ The Arreat Summit để tham khảo. Không xem ảnh tham khảo là tài nguyên được cấp phép để đưa vào game thương mại. Xem `assets/SOURCES.json` để truy nguồn từng ảnh. Nội dung mô tả và checklist là ghi chú sản xuất của dự án, không phải văn bản chép nguyên từ nguồn.

Three.js được sử dụng theo giấy phép MIT; xem `THIRD_PARTY_LICENSES.txt`. Bản khóa dependency được lưu trong package-lock.json. Phần JavaScript của Three.js đã được nhúng vào bản HTML.
