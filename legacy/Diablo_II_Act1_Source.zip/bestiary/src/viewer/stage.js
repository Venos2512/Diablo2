import * as THREE from 'three';
import {OrbitControls} from 'three/addons/controls/OrbitControls.js';

/** A Three.js reference stage. This displays a flat reference image, not a character model. */
export function createStage(host){
 let renderer;
 try{renderer=new THREE.WebGLRenderer({antialias:true,alpha:true});}catch{return null;}
 renderer.setPixelRatio(Math.min(devicePixelRatio,2));renderer.outputColorSpace=THREE.SRGBColorSpace;
 renderer.domElement.setAttribute('aria-label','Sân khấu 3D trưng bày ảnh tham khảo');host.append(renderer.domElement);
 const scene=new THREE.Scene();
 const camera=new THREE.PerspectiveCamera(38,1,.1,80);camera.position.set(0,2.3,7.2);
 const controls=new OrbitControls(camera,renderer.domElement);controls.target.set(0,1.45,0);controls.enableDamping=true;controls.enablePan=false;controls.minDistance=4;controls.maxDistance=11;controls.minPolarAngle=.55;controls.maxPolarAngle=1.6;
 scene.add(new THREE.HemisphereLight(0xffe8c7,0x18201c,3));
 const key=new THREE.DirectionalLight(0xffbb77,4);key.position.set(3,5,3);scene.add(key);
 const base=new THREE.Mesh(new THREE.CylinderGeometry(1.65,1.8,.22,64),new THREE.MeshStandardMaterial({color:0x292b25,metalness:.65,roughness:.5}));base.position.y=.02;scene.add(base);
 const ring=new THREE.Mesh(new THREE.TorusGeometry(1.57,.012,8,96),new THREE.MeshBasicMaterial({color:0xb89560}));ring.rotation.x=Math.PI/2;ring.position.y=.145;scene.add(ring);
 const grid=new THREE.PolarGridHelper(2.4,16,4,64,0x64533c,0x33362d);grid.position.y=-.1;scene.add(grid);
 const artCanvas=document.createElement('canvas');artCanvas.width=512;artCanvas.height=512;
 const context=artCanvas.getContext('2d');const texture=new THREE.CanvasTexture(artCanvas);texture.colorSpace=THREE.SRGBColorSpace;texture.magFilter=THREE.NearestFilter;
 const board=new THREE.Mesh(new THREE.PlaneGeometry(3,3),new THREE.MeshBasicMaterial({map:texture,transparent:true,side:THREE.DoubleSide}));board.position.y=1.72;scene.add(board);
 let img=null,disposed=false,auto=false,request=0;
 const size=()=>{const {width,height}=host.getBoundingClientRect();if(!width||!height)return;renderer.setSize(width,height,false);camera.aspect=width/height;camera.updateProjectionMatrix();};
 const observer=new ResizeObserver(size);observer.observe(host);size();
 function draw(){if(!img?.complete||!img.naturalWidth)return;context.clearRect(0,0,512,512);const scale=Math.min(470/img.naturalWidth,470/img.naturalHeight);const w=img.naturalWidth*scale,h=img.naturalHeight*scale;context.imageSmoothingEnabled=false;context.drawImage(img,(512-w)/2,(512-h)/2,w,h);texture.needsUpdate=true;}
 function loop(){if(disposed)return;request=requestAnimationFrame(loop);controls.autoRotate=auto;controls.autoRotateSpeed=.6;controls.update();board.quaternion.copy(camera.quaternion);draw();renderer.render(scene,camera);}
 loop();
 return {
  select(monster){img=new Image();img.src=monster.image.src;img.onload=draw;},
  reset(){camera.position.set(0,2.3,7.2);controls.target.set(0,1.45,0);controls.update();},
  toggle(){auto=!auto;return auto;},
  dispose(){disposed=true;cancelAnimationFrame(request);observer.disconnect();controls.dispose();scene.traverse(o=>{o.geometry?.dispose();if(o.material)o.material.dispose();});texture.dispose();renderer.dispose();renderer.domElement.remove();}
 };
}
