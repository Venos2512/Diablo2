import images from './images.json';

export const groups = [
  {id:'imps',name:'Quỷ nhỏ & pháp sư',icon:'01',color:'#cf784a',brief:'Dáng nhỏ, nhịp chuyển động nhanh, tương phản giữa chiến binh và pháp sư.'},
  {id:'rogues',name:'Rogue bị tha hóa',icon:'02',color:'#b87068',brief:'Hình người; vũ khí và tư thế giúp phân biệt kiếm, cung và giáo.'},
  {id:'undead',name:'Xác sống & bộ xương',icon:'03',color:'#b8ad81',brief:'Tương phản thịt mục và khung xương, chuyển động nặng hoặc khô cứng.'},
  {id:'spirits',name:'Linh thể & hắc ám',icon:'04',color:'#869eae',brief:'Hình dáng siêu nhiên, lơ lửng và phép thuật tạo điểm nhận diện.'},
  {id:'wildlife',name:'Sinh vật hoang dã',icon:'05',color:'#95a778',brief:'Ba cấu trúc cơ thể khác biệt: gai, cánh và nhiều chân.'},
  {id:'brutes',name:'Quỷ thú & quái lớn',icon:'06',color:'#ae956a',brief:'Khối cơ thể lớn, bước chân và đòn đánh cần thể hiện trọng lượng.'},
  {id:'bosses',name:'Kẻ thù đặc biệt',icon:'07',color:'#cc6556',brief:'Hình dáng nổi bật, vũ khí và hiệu ứng có nhận diện riêng.'},
  {id:'constructs',name:'Vật thể thù địch',icon:'08',color:'#8d9f9c',brief:'Vật thể bay, tổ sinh quái và bẫy cần bộ trạng thái riêng.'},
];

// Descriptions and animation lists are original production notes, not extracted game data.
// [name, group, role, silhouette, art focus, suggested special motion, location, base reference]
const rows = [
 ['Fallen','imps','Cận chiến','Quỷ nhỏ, dáng khom, tay cầm vũ khí và tấm khiên nhỏ.','Giữ đầu, tay và vũ khí rõ khi thu nhỏ; tách biến thể màu khỏi hình gốc.','Bỏ chạy; quay lại giao chiến','',''],
 ['Fallen Shaman','imps','Thi triển phép','Pháp sư quỷ nhỏ với gậy và trang sức nổi bật trên thân.','Tách hình dáng pháp sư khỏi Fallen thường; chú ý đầu gậy và hiệu ứng phép.','Thi triển phép; hồi sinh','','Fallen'],
 ['Fetish','imps','Cận chiến','Sinh vật hình người rất nhỏ với vũ khí lớn so với thân.','Ưu tiên chân, đầu và vũ khí; tránh mất hình khi bị quái lớn che.','Đánh nhanh','',''],
 ['Bishibosh','imps','Thi triển phép','Quái đặc biệt thuộc nhóm Fallen Shaman.','Dùng ảnh để đối chiếu màu và trang sức; hiệu ứng riêng cần quản lý tách biệt.','Thi triển phép','Cold Plains','Fallen Shaman'],
 ['Rakanishu','imps','Cận chiến','Chiến binh nhỏ thuộc nhánh Carver của nhóm Fallen.','Phân biệt bằng màu và hiệu ứng điện; kiểm tra khả năng dùng lại hình nền.','Phản hồi hiệu ứng điện','Stony Field','Fallen'],
 ['Corrupt Rogue','rogues','Cận chiến','Nữ chiến binh hình người, dáng thon, trang bị đánh gần.','Dáng đứng, tóc và đường vũ khí phải đọc rõ ở góc nhìn game.','Vung vũ khí','',''],
 ['Corrupt Rogue Archer','rogues','Đánh xa','Rogue dùng cung, thân xoay theo hướng ngắm bắn.','Cung và dây cung cần đọc được; giữ điểm phóng tên nhất quán.','Kéo cung; bắn','','Corrupt Rogue'],
 ['Corrupt Rogue Spearwoman','rogues','Cận chiến','Rogue cầm giáo dài, hình dáng trải rộng theo trục vũ khí.','Kiểm tra đầu giáo, điểm cầm và khoảng đâm ở từng hướng.','Đâm giáo','','Corrupt Rogue'],
 ['Blood Raven','rogues','Đánh xa','Nữ cung thủ đặc biệt tại nghĩa địa, nổi bật trong đám xác sống.','Duyệt riêng tư thế cung, màu sắc và hiệu ứng liên quan tới cuộc chạm trán.','Bắn; thi triển kỹ năng','Burial Grounds','Corrupt Rogue Archer'],
 ['Coldcrow','rogues','Đánh xa','Cung thủ đặc biệt thuộc nhóm Dark Ranger.','So sánh bộ cung thủ nền và màu; quản lý hiệu ứng lạnh riêng.','Bắn; phản hồi lạnh','Cave','Corrupt Rogue Archer'],
 ['The Countess','rogues','Cận chiến','Nữ chiến binh đặc biệt thuộc nhóm Dark Stalker.','Đối chiếu silhouette Rogue và phối màu; tách hiệu ứng lửa khỏi chuyển động.','Đánh; hiệu ứng lửa','Forgotten Tower','Corrupt Rogue'],
 ['Zombie','undead','Cận chiến','Xác sống hình người, vai rũ và thân nặng nề.','Tạo cảm giác thịt mục bằng mảng lớn; bước chân cần thể hiện sức nặng.','Lết bước','',''],
 ['Skeleton','undead','Cận chiến','Khung xương người, vũ khí cận chiến và có thể có khiên.','Khoảng trống giữa xương quan trọng hơn chi tiết bề mặt.','Vung vũ khí','',''],
 ['Skeleton Archer','undead','Đánh xa','Khung xương mang cung, tay kéo căng khi bắn.','Giữ các chi đủ rõ trên nền tối; cung cần tách khỏi lồng ngực.','Kéo cung; bắn','','Skeleton'],
 ['Skeleton Mage','undead','Thi triển phép','Bộ xương thi triển đạn phép từ tay.','Tách màu xương, ánh phép và điểm xuất phát của đạn.','Thi triển đạn phép','','Skeleton'],
 ['Corpsefire','undead','Cận chiến','Zombie đặc biệt trong Den of Evil.','Dùng ảnh chạm trán để đối chiếu màu; tránh làm mới chuyển động nếu có thể tái sử dụng.','Đánh; hiệu ứng thuộc tính','Den of Evil','Zombie'],
 ['Bonebreaker','undead','Cận chiến','Chiến binh xương đặc biệt tại Crypt.','So sánh vũ khí và bộ xương nền trước khi tách thành bộ art riêng.','Vung vũ khí','Crypt','Skeleton'],
 ['Bone Ash','undead','Thi triển phép','Pháp sư xương đặc biệt thuộc nhóm Burning Dead Mage.','Đối chiếu màu và phép; giữ nhận diện pháp sư xương giữa nội thất Cathedral.','Thi triển phép','Cathedral','Skeleton Mage'],
 ['Wraith','spirits','Cận chiến','Linh thể kéo dài, phần thân dưới tan vào hình dạng mờ.','Rìa trong suốt và hình khối phải còn rõ trên nền dungeon tối.','Lơ lửng; tan biến','',''],
 ['Vampire','spirits','Thi triển phép','Pháp sư xác sống với dáng cao và trang phục dài.','Ưu tiên tay, đầu và phần tà; quản lý phép tách khỏi thân.','Thi triển phép','',''],
 ['Spike Fiend','wildlife','Đánh xa','Thú thấp với nhiều gai nhô lên lưng.','Gai tạo đường viền đặc trưng; cần thấy hướng phóng.','Bắn gai','',''],
 ['Blood Hawk','wildlife','Bay','Chim quái với cánh rộng hơn thân.','Duyệt dáng cánh ở pha khép và mở; giữ thân đọc được.','Vỗ cánh; lao vào','',''],
 ['Giant Spider','wildlife','Cận chiến','Nhện lớn với bụng tròn và nhiều chân dài.','Kiểm tra nhịp chân, khoảng trống giữa chân và vùng tiếp đất.','Di chuyển nhiều chân','',''],
 ['Wendigo','brutes','Cận chiến','Thú dạng người to lớn phủ lông, tay dài và vai rộng.','Khối lông phải gọn; vai và tay truyền trọng lượng đòn đánh.','Đập tay','',''],
 ['Goatman','brutes','Cận chiến','Sinh vật đầu dê, sừng rõ và hai chân dạng thú.','Tập trung vào sừng, chân và vũ khí; tránh lẫn với dáng người.','Vung vũ khí','',''],
 ['Tainted','brutes','Hỗn hợp','Quỷ thú có sừng, thân nặng và miệng nổi bật.','Tách tư thế tấn công gần với động tác phóng đạn.','Đánh gần; phóng đạn','',''],
 ['Treehead Woodfist','brutes','Cận chiến','Quái đặc biệt thuộc nhánh Brute của Wendigo.','Rà khả năng dùng chung bộ chuyển động với Wendigo; đối chiếu màu.','Đập tay','Dark Wood','Wendigo'],
 ['Pitspawn Fouldog','brutes','Hỗn hợp','Quỷ thú đặc biệt thuộc nhóm Tainted trong khu nhà tù.','Đối chiếu bộ hình Tainted và phối màu; kiểm tra hiệu ứng lạnh riêng.','Đánh gần; phóng đạn','Jail tầng 2','Tainted'],
 ['Griswold','bosses','Cận chiến','Người thợ rèn bị tha hóa với thân hình nặng và vai rộng.','Giữ hình dáng riêng; cân đối thân nặng với đòn đánh ngắn.','Đánh gần','Tristram',''],
 ['The Smith','bosses','Cận chiến','Quỷ thợ rèn khổng lồ mang búa lớn.','Búa, bụng và vai là các mảng nhận diện; kiểm tra cung vung búa.','Vung búa','Barracks',''],
 ['Andariel','bosses','Boss','Ác quỷ nữ cao lớn, các chi nhọn vươn ra sau lưng.','Silhouette nhiều chi phải đọc rõ; hiệu ứng độc cần nổi bật nhưng không che thân.','Đánh; phóng độc; chết đặc biệt','Catacombs tầng 4',''],
 ['Flying Scimitar','constructs','Vật thể','Thanh đao tự bay, không có người cầm.','Lưỡi đao và độ nghiêng tạo nhận diện; cần đường chuyển động rõ.','Lơ lửng; chém','',''],
 ['Blood Hawk Nest','constructs','Nguồn sinh quái','Tổ chim quái cố định trên mặt đất.','Đủ trạng thái nguyên vẹn, sinh quái và bị phá hủy.','Sinh chim; bị phá','',''],
 ['Gargoyle Trap','constructs','Bẫy','Tượng bẫy cố định phóng đạn vào khu vực giao tranh.','Tách rõ vật trang trí và vật gây nguy hiểm qua miệng phóng, nhịp phát sáng.','Kích hoạt; phóng đạn','',''],
];
export const monsters=rows.map((r,i)=>{
 const [name,group,role,description,art,special,location,base]=r;
 const kind=name==='Andariel'?'boss':location?'unique':'regular';
 const stationary=['Nguồn sinh quái','Bẫy'].includes(role);
 return {id:name.toLowerCase().replace(/[^a-z0-9]+/g,'-'),index:i+1,name,group,role,description,art,location:location||'Nhóm trong Bestiary Act I',base,kind,
   motions:stationary?['Chờ',...special.split('; ')]:['Chờ','Di chuyển','Tấn công','Trúng đòn (kiểm tra)','Chết',...special.split('; ')],
   image:images[name],scope:'Danh mục tham khảo Act I; vị trí spawn theo phiên bản và độ khó chưa kiểm kê.'};
});
export const groupById=Object.fromEntries(groups.map(g=>[g.id,g]));
