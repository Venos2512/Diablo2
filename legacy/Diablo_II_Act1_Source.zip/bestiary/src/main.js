import {monsters,groups,groupById} from './data/catalog.js';
import {filterMonsters,loadNotes,saveNotes,exportNotes} from './lib/state.js';
import {createStage} from './viewer/stage.js';

const $=id=>document.getElementById(id);
const state={group:'all',kind:'all',query:'',selected:'fallen'};
let visible=monsters;const notes=loadNotes();
const stage=createStage($('stage'));
if(!stage){$('stage-fallback').hidden=false;document.querySelector('.stage-controls span').textContent='Chế độ ảnh · WebGL không khả dụng';$('rotate').disabled=true;$('reset-view').disabled=true;}

function groupButton(id,label,icon,count){
 const b=document.createElement('button');b.className='group-button';b.dataset.group=id;
 const a=document.createElement('span');a.className='group-icon';a.textContent=icon;
 const text=document.createElement('span');text.textContent=label;
 const number=document.createElement('span');number.className='group-count';number.textContent=String(count).padStart(2,'0');
 b.append(a,text,number);b.addEventListener('click',()=>{state.group=id;render();});return b;
}
$('groups').append(groupButton('all','Tất cả kẻ thù','◇',monsters.length),...groups.map(g=>groupButton(g.id,g.name,g.icon,monsters.filter(m=>m.group===g.id).length)));

function select(id,{scroll=false}={}){
 const m=monsters.find(m=>m.id===id);if(!m)return;state.selected=id;
 document.querySelectorAll('.card').forEach(b=>{b.classList.toggle('active',b.dataset.id===id);b.setAttribute('aria-pressed',String(b.dataset.id===id));});
 $('detail-name').textContent=m.name;$('detail-kind').textContent=m.kind==='boss'?'BOSS CUỐI ACT':m.kind==='unique'?'QUÁI ĐẶC BIỆT':'NHÓM QUÁI / VẬT THỂ';
 $('detail-role').textContent=m.role+' · '+groupById[m.group].name;
 $('description').textContent=m.description;$('detail-group').textContent=groupById[m.group].name;
 $('location').textContent=m.location;$('base').textContent=m.base||'Cần đối chiếu bộ hình riêng';
 $('art').textContent=m.art;$('source').href=m.image.source;
 $('motions').replaceChildren(...m.motions.map(t=>{const s=document.createElement('span');s.textContent=t;return s;}));
 $('note').value=typeof notes[id]==='string'?notes[id]:'';$('save-status').textContent='Lưu trên trình duyệt';
 $('large-image').src=m.image.src;$('large-image').alt='Hình tham khảo '+m.name;$('image-title').textContent=m.name;
 $('stage-fallback').src=m.image.src;$('stage-fallback').alt='Hình tham khảo '+m.name;
 stage?.select(m);updateNavigation();
 if(scroll&&matchMedia('(max-width:620px)').matches)document.querySelector('.detail').scrollIntoView({behavior:matchMedia('(prefers-reduced-motion:reduce)').matches?'instant':'smooth'});
}
function updateNavigation(){const i=visible.findIndex(m=>m.id===state.selected);$('previous').disabled=i<=0;$('next').disabled=i<0||i>=visible.length-1;}
function card(m){
 const b=document.createElement('button');b.className='card'+(m.kind==='regular'?'':' special');b.dataset.id=m.id;b.style.setProperty('--group-color',groupById[m.group].color);b.setAttribute('aria-label','Xem '+m.name);
 const picture=document.createElement('div');picture.className='card-image';
 const image=new Image();image.src=m.image.src;image.alt=m.name;image.loading='lazy';
 const number=document.createElement('span');number.className='card-number';number.textContent=String(m.index).padStart(2,'0');
 const dot=document.createElement('span');dot.className='card-dot';picture.append(image,number,dot);
 const info=document.createElement('div');info.className='card-info';const name=document.createElement('span');name.className='card-name';name.textContent=m.name;
 const bottom=document.createElement('div');bottom.className='card-bottom';const role=document.createElement('span');role.textContent=m.role;
 const badge=document.createElement('span');badge.className='card-badge';badge.textContent=m.kind==='boss'?'BOSS':m.kind==='unique'?'ĐẶC BIỆT':'↗';bottom.append(role,badge);info.append(name,bottom);b.append(picture,info);
 b.addEventListener('click',()=>select(m.id,{scroll:true}));return b;
}
function render(){
 visible=filterMonsters(monsters,state);
 document.querySelectorAll('.group-button').forEach(b=>{b.classList.toggle('active',b.dataset.group===state.group);b.setAttribute('aria-pressed',String(b.dataset.group===state.group));});
 $('group-title').textContent=state.group==='all'?'Tất cả kẻ thù':groupById[state.group].name;
 $('group-brief').textContent=state.group==='all'?'Chọn một hồ sơ để xem hình tham khảo và ghi chú sản xuất.':groupById[state.group].brief;
 $('result-count').textContent=visible.length+' / 34 hồ sơ';$('cards').replaceChildren(...visible.map(card));$('empty').hidden=visible.length>0;
 if(visible.length&&!visible.some(m=>m.id===state.selected))state.selected=visible[0].id;
 select(state.selected);
}
$('search').addEventListener('input',e=>{state.query=e.target.value;render();});
$('kind').addEventListener('change',e=>{state.kind=e.target.value;render();});
$('clear-filters').addEventListener('click',()=>{Object.assign(state,{group:'all',kind:'all',query:''});$('search').value='';$('kind').value='all';render();});
$('previous').addEventListener('click',()=>{const i=visible.findIndex(m=>m.id===state.selected);if(i>0)select(visible[i-1].id);});
$('next').addEventListener('click',()=>{const i=visible.findIndex(m=>m.id===state.selected);if(i>=0&&i<visible.length-1)select(visible[i+1].id);});
const tabs=[...document.querySelectorAll('[data-tab]')];
function activateTab(button){tabs.forEach(b=>{const active=b===button;b.setAttribute('aria-selected',String(active));b.tabIndex=active?0:-1;$(b.dataset.tab).hidden=!active;});}
tabs.forEach((b,i)=>{b.addEventListener('click',()=>activateTab(b));b.addEventListener('keydown',e=>{if(['ArrowLeft','ArrowRight'].includes(e.key)){e.preventDefault();const next=tabs[(i+1)%tabs.length];activateTab(next);next.focus();}});});
$('note').addEventListener('input',e=>{notes[state.selected]=e.target.value;$('save-status').textContent=saveNotes(notes)?'Đã lưu':'Không lưu được · hãy xuất JSON';});
$('export-notes').addEventListener('click',()=>exportNotes(notes));
$('enlarge').addEventListener('click',()=>$('image-dialog').showModal());
['open-docs','scope-info'].forEach(id=>$(id).addEventListener('click',()=>$('docs-dialog').showModal()));
document.querySelectorAll('dialog').forEach(d=>{d.querySelector('.close').addEventListener('click',()=>d.close());d.addEventListener('click',e=>{if(e.target===d){const r=d.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)d.close();}});});
$('rotate').addEventListener('click',()=>{$('rotate').setAttribute('aria-pressed',String(stage?.toggle()));});$('reset-view').addEventListener('click',()=>stage?.reset());
document.addEventListener('keydown',e=>{if(e.key==='/'&&!['INPUT','TEXTAREA','SELECT'].includes(document.activeElement.tagName)&&!document.querySelector('dialog[open]')){e.preventDefault();$('search').focus();}});
window.addEventListener('pagehide',()=>stage?.dispose(),{once:true});render();
